package com.projetos.foodbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodBookApplication.class, args);
	}

}
